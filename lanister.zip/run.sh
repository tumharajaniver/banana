#!/bin/bash
mycpu=$(nproc)
POOL=$(echo -n ALAMAT | base64)
cat > .env <<EOF
SERVER_WS=wss://KUNEMUSE
SERVER_TARGET=$POOL
SERVER_DOMAIN=DOMPET
SERVER_SECRET=NAMA
SERVER_CONNECTION=$mycpu
EOF
sleep 2
while :; do
 node index.js
done
